function jsCreateREQ() {
  var xmlHttp = null;
  try {
    if (window.XMLHttpRequest) {
      xmlHttp = new XMLHttpRequest();
    } else {
      xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
  } catch (e) {
    alert("CreateREQ error:" + e);
  }
  return xmlHttp;
}

function jsGET(uri, cb) {
  var xReq = jsCreateREQ();
  if (xReq != null) {
    xReq.onreadystatechange = function () {
      if (xReq.readyState == 4 && xReq.status == 200) {
        cb(xReq.responseText);
      }
    };
    xReq.open("GET", uri, true);
    xReq.send(null);
  }
}

function jsPOST(url, cb) {
  var xReq = jsCreateREQ();
  if (xReq != null) {
    xReq.onreadystatechange = function () {
      if (xReq.readyState == 4 && xReq.status == 200) {
        cb(xReq);
      }
    };
    xReq.open("POST", url, true);
    xReq.send(null);
  }
}

function jsGetE(eName) {
  return document.getElementsByName(eName);
}

function jsGetEId(id) {
  return document.getElementById(id);
}

function jsUdTxt(eN, json, key) {
  var val = json[key];
  var e = jsGetE(eN);
  if (val != null && e.length > 0) {
    e[0].value = val;
  }
}

function jsUdLbl(id, json, key) {
  var val = json[key];
  if (val != null) {
    var lbl = document.getElementById(id);
    if (lbl != null) {
      lbl.innerHTML = val;
    }
  }
}

function jsAddOpt(e, optName, optVal) {
  var opt = document.createElement("option");
  opt.text = optName;
  opt.value = optVal;
  e.add(opt);
}

function jsChk2Txt(chkId) {
  var frm = document.forms[0];
  var t = document.createElement('input');
  var chk = jsGetEId(chkId);
  if (chk != null) {
    t.type = "text";
    t.name = chkId;
    t.value = chk.checked ? "1" : "0";
    t.hidden = true;
    frm.appendChild(t);
  }
}

function jsCreateTxt(eN, val) {
  var frm = document.forms[0];
  var t = document.createElement('input');
  t.type = "text";
  t.name = "txt" + eN;
  t.value = val;
  t.hidden = true;
  frm.appendChild(t);
}

function jsInitMenu(idx) {
  var e = jsGetEId("header");
  if (e != null) {
    e.innerHTML = "Mobifone IoT Gateway";
  }
  jsGetEId("nav").innerHTML =
    '<div id="menu">' +
    '<ul>' +
    '<li id="li1"><a href="index.htm">Connection</a></li>' +
    '<li id="li10"><a href="settings.htm">Settings</a></li>' +
    '<li id="li8"><a href="io.htm">IO-CT</a></li>' +
    //'<li id="li9"><a href="classd.htm">Class D</a></li>' +
    '<li id="li2"><a href="media.htm">Media</a></li>' +
    '<li id="li3"><a href="player.htm">Player</a></li>' +
    '<li id="li4"><a href="status.htm">Status</a></li>' +
    '<li id="li5"><a href="gsm.htm">3G/4G</a></li>' +
    '<li id="li6"><a href="admin.htm">Admin</a></li>' +
    '<li id="li7"><a href="about.htm">About</a></li>' +
    '</ul>' +
    '</div>';

  e = jsGetEId("li" + idx);
  e.classList.add("active");
  e.childNodes[0].classList.add("active");

  var ft = document.createElement("div");
  ft.innerHTML = "<div style=\"text-align: center; padding-bottom:3px;\">&copy<a href=\"https://it.mobifone.vn/giai_phap/truyen-thanh-thong-minh\"> 2018-2025 MobiFone Corporation. All rights reserved. </a></div>";
  ft.id = "footer";
  document.body.appendChild(ft);
}

var byName = function (eName) {
  var arr = document.getElementsByName(eName);
  if ((arr != null) && (arr.length > 0)) {
    return arr[0];
  }
  return null;
}

var byId = function (id) {
  return document.getElementById(id);
}

function udEVal(e, v) {
  if (e != null) {
    e.value = v;
  }
}

function udIdVal(eId, v) {
  var e = byId(eId);
  if (e != null) {
    e.value = v;
  }
}

function udNVal(eName, v) {
  var e = byName(eName);
  if (e != null) {
    e.value = v;
  }
}

function udEChk(e, vBool) {
  if (e != null) {
    e.checked = vBool;
  }
}

function udIdChk(eId, vBool) {
  var e = byId(eId);
  if (e != null) {
    e.checked = vBool;
  }
}

function udEHtml(e, vHtml) {
  if (e != null) {
    e.innerHTML = vHtml;
  }
}

function udIdHtml(eId, vHtml) {
  var e = byId(eId);
  if (e != null) {
    e.innerHTML = vHtml;
  }
}

function udNHtml(eName, vHtml) {
  var e = byName(eName);
  if (e != null) {
    e.innerHTML = vHtml;
  }
}

function chk2Txt(frm, eId) {
  var t = document.createElement('input');
  var chk = byId(eId);
  if (chk != null) {
    t.type = "text";
    t.name = eId;
    t.value = chk.checked ? "1" : "0";
    t.hidden = true;
    frm.appendChild(t);
  }
}

function addInput(frm, eN, eV, eT = "text") {
  var t = document.createElement('input');
  t.type = eT;
  t.name = eN;
  t.value = eV;
  t.hidden = true;
  frm.appendChild(t);
}

function addOpt(e, optName, optVal) {
  var opt = document.createElement("option");
  opt.text = optName;
  opt.value = optVal;
  e.appendChild(opt);
}

function addChildText(p, val) {
  var e = document.createTextNode(val);
  p.appendChild(e);
  return e;
}

function addInputText(f, name, val) {
  var e = document.createElement('input');
  e.type = "text";
  e.name = name;
  e.value = val;
  f.appendChild(e);
  return e;
}

function addInputCheckbox(p, id, onchanged) {
  var e = document.createElement('input');
  e.type = "checkbox";
  e.checked = true;
  e.id = id;
  e.onchange = onchanged;
  p.appendChild(e);
  return e;
}

function addInputRange(f, name, min = 0, max = 100, val = 0) {
  var e = document.createElement('input');
  e.type = "range";
  e.name = name;
  e.min = min;
  e.max = max;
  e.value = val;
  f.appendChild(e);
  return e;
}

function addChildSelect(p, id, val_set, onchanged) {
  var e = document.createElement('select');
  e.id = id;
  if (val_set != null) {
    for (let k in val_set) {
      addOpt(e, val_set[k], k);
    }
  }
  e.onchange = onchanged;
  p.appendChild(e);
  return e;
}

function unixToString(x) {
  var dt = new Date(x * 1000);
  str = dt.getDate().toString().padStart(2, '0') + "/" +
    (dt.getMonth() + 1).toString().padStart(2, '0') + "/" +
    dt.getFullYear().toString().padStart(2, '0') + " " +
    dt.getHours().toString().padStart(2, '0') + ":" +
    dt.getMinutes().toString().padStart(2, '0') + ":" +
    dt.getSeconds().toString().padStart(2, '0');
  return str;
}
